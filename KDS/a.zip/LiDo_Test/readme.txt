readme.txt
----------
Test project for low power settings.
